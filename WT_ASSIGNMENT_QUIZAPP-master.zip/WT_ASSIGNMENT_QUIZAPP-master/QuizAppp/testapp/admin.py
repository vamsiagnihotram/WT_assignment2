from django.contrib import admin
from testapp.models import USER_LOGIN,USER_RESULT
# Register your models here.
admin.site.register(USER_LOGIN)
admin.site.register(USER_RESULT)